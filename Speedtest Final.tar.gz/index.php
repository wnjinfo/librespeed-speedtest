<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Teste de velocidade Terra Fibra Goiás">
    <link rel="shortcut icon" href="favicon.ico">
    <title>Speedtest Terra Fibra - GO</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome para ícones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Script do Speedtest -->
    <script type="text/javascript" src="speedtest.js"></script>
    
    <style>
        :root {
            --primary-color: #4a6bff;
            --secondary-color: #6060AA;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
            --ping-color: #6a5acd; /* Roxo suave para Ping */
            --jitter-color: #20b2aa; /* Verde-água para Jitter */
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --body-bg: #f5f7ff;
            --text-color: #212529;
            --card-bg: #ffffff;
            --meter-bg: #80808040;
        }
        
        [data-bs-theme="dark"] {
            --body-bg: #121225;
            --text-color: #f8f9fa;
            --card-bg: #1e1e2e;
            --meter-bg: #2a2a3a;
            --primary-color: #5c7cff;
            --secondary-color: #7070bb;
            --ping-color: #9370db;
            --jitter-color: #3cb371;
        }
        
        body {
            background-color: var(--body-bg);
            color: var(--text-color);
            transition: background-color 0.3s ease, color 0.3s ease;
            background-image: 
                radial-gradient(circle at 75% 30%, rgba(74, 107, 255, 0.15) 0%, transparent 25%),
                linear-gradient(135deg, rgba(100,149,237,0.08) 0%, rgba(0,0,0,0) 50%, rgba(100,149,237,0.08) 100%),
                linear-gradient(45deg, rgba(138,43,226,0.08) 0%, rgba(0,0,0,0) 50%, rgba(138,43,226,0.08) 100%),
                url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100" opacity="0.03"><path d="M0,50 Q25,25 50,50 T100,50" stroke="%234a6bff" fill="none" stroke-width="1"/><path d="M0,40 Q25,15 50,40 T100,40" stroke="%234a6bff" fill="none" stroke-width="1"/><path d="M0,60 Q25,35 50,60 T100,60" stroke="%234a6bff" fill="none" stroke-width="1"/></svg>');
            background-size: 
                cover,
                cover,
                cover,
                200px;
            background-attachment: fixed;
            background-position: center;
        }

        /* Efeito de brilho dinâmico para simular fibra ótica */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(ellipse at center, rgba(74,107,255,0.2) 0%, rgba(74,107,255,0) 70%);
            pointer-events: none;
            z-index: -1;
            animation: pulse 15s infinite alternate;
        }

        @keyframes pulse {
            0% { opacity: 0.3; }
            100% { opacity: 0.7; }
        }

        .top-bar {
            background: linear-gradient(90deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.9) 20%, rgba(74,107,255,0.9) 100%);
            backdrop-filter: blur(8px);
        }

        [data-bs-theme="dark"] .top-bar {
            background: linear-gradient(90deg, rgba(30,30,46,0.9) 0%, rgba(30,30,46,0.9) 20%, rgba(74,107,255,0.9) 100%);
        }

        
        .top-bar {
            background: linear-gradient(90deg, var(--body-bg) 0%, var(--body-bg) 20%, var(--primary-color) 100%);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(5px);
        }
        
        .logo {
            height: 40px;
            transition: transform 0.3s ease;
        }
        
        .logo:hover {
            transform: scale(1.05);
        }
        
        .theme-toggle {
            background: none;
            border: none;
            font-size: 1.2rem;
            color: var(--text-color);
            cursor: pointer;
            transition: transform 0.3s ease;
        }
        
        .theme-toggle:hover {
            transform: scale(1.1);
        }
        
        #startStopBtn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            transition: all 0.3s;
            font-weight: 600;
        }
        
        #startStopBtn:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        
        #startStopBtn.running {
            background-color: var(--danger-color);
        }
        
        .test-card {
            background-color: var(--card-bg);
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .test-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
        }
        
        .meter-container {
            position: relative;
            height: 150px;
            margin-bottom: 10px;
        }
        
        .meter-value {
            font-size: 1.8rem;
            font-weight: bold;
            margin-top: 5px;
        }
        
        .small-meter-value {
            font-size: 1.5rem;
            font-weight: bold;
            margin-top: 5px;
        }
        
        .test-name {
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--primary-color);
        }
        
        .unit {
            font-size: 0.8rem;
            color: #6c757d;
        }
        
        #ipArea {
            margin-top: 20px;
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .ping-jitter-row {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 15px;
        }
        
        .ping-jitter-card {
            flex: 1;
            min-width: 120px;
            max-width: 160px;
        }
        
        @media (max-width: 768px) {
            .top-bar {
                background: linear-gradient(90deg, var(--body-bg) 0%, var(--body-bg) 30%, var(--primary-color) 100%);
            }
            
            .meter-value {
                font-size: 1.5rem;
            }
            
            .small-meter-value {
                font-size: 1.3rem;
            }
            
            .test-name {
                font-size: 0.9rem;
            }
            
            .ping-jitter-card {
                min-width: 100px;
            }
            
            body {
                background-size: 150px;
            }
        }
        /* Seu CSS existente */
        .logo {
            height: 40px;
            transition: all 0.3s ease;
        }
:root {
    --dl-color: #8f16fa;    /* Roxo para download */
    --ul-color: #16fa8f;    /* Verde para upload */
    --meter-bg: #f0f0f0;    /* Fundo do medidor */
}

[data-bs-theme="dark"] {
    --dl-color: #b56aff;    /* Roxo claro para dark mode */
    --ul-color: #5affb5;    /* Verde claro para dark mode */
    --meter-bg: #2a2a2a;    /* Fundo escuro */
}
    </style>
</head>
<body>
    <!-- Barra Superior -->
<nav class="navbar top-bar fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="logo.svg" alt="Terra Fibra Goiás" class="logo" id="logoImage">
        </a>
        <div class="d-flex align-items-center">
            <button class="theme-toggle me-3" id="themeToggle">
                <i class="fas fa-moon"></i>
            </button>
            <button class="btn btn-light reload-btn" onclick="window.location.reload()">
                <i class="fas fa-sync-alt me-2"></i>Recarregar
            </button>
        </div>
    </div>
</nav>

    <div class="container mt-5 pt-4">
        <h1 class="text-center mb-4">Speedtest Terra Fibra - GO</h1>
        
        <div class="d-flex justify-content-center mb-4">
            <button id="startStopBtn" class="btn btn-lg px-4 py-2" onclick="startStop()">
                <i class="fas fa-play me-2"></i>Testar
            </button>
        </div>
        
        <div class="ping-jitter-row">
            <!-- Ping -->
            <div class="test-card text-center ping-jitter-card">
                <div class="test-name">Ping</div>
                <div id="pingText" class="small-meter-value" style="color: var(--ping-color)">-</div>
                <div class="unit">ms</div>
            </div>
            
            <!-- Jitter -->
            <div class="test-card text-center ping-jitter-card">
                <div class="test-name">Jitter</div>
                <div id="jitText" class="small-meter-value" style="color: var(--jitter-color)">-</div>
                <div class="unit">ms</div>
            </div>
        </div>
        
        <div class="row justify-content-center">
            <!-- Download -->
            <div class="col-md-5 mb-3">
                <div class="test-card">
                    <div class="test-name text-center">Download</div>
                    <div class="meter-container">
                        <canvas id="dlMeter" class="w-100 h-100"></canvas>
                    </div>
                    <div class="text-center">
                        <div id="dlText" class="meter-value">-</div>
                        <div class="unit">Mbit/s</div>
                    </div>
                </div>
            </div>
            
            <!-- Upload -->
            <div class="col-md-5 mb-3">
                <div class="test-card">
                    <div class="test-name text-center">Upload</div>
                    <div class="meter-container">
                        <canvas id="ulMeter" class="w-100 h-100"></canvas>
                    </div>
                    <div class="text-center">
                        <div id="ulText" class="meter-value">-</div>
                        <div class="unit">Mbit/s</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-3" id="ipArea">
            <span id="ip" class="text-muted"></span>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script type="text/javascript">
        function I(i){return document.getElementById(i);}
 function updateThemeIcon(theme) {
    const icon = I('themeToggle').querySelector('i');
    const logo = I('logoImage');
    
    if (theme === 'dark') {
        icon.classList.replace('fa-moon', 'fa-sun');
        logo.src = 'logo_white.png'; // Logo para tema escuro
    } else {
        icon.classList.replace('fa-sun', 'fa-moon');
        logo.src = 'logo.svg'; // Logo para tema claro
    }
}      
// Configuração do tema
function setupTheme() {
    const themeToggle = document.getElementById('themeToggle');
    
    // Verifica se há um tema salvo, caso contrário usa dark como padrão
    const savedTheme = localStorage.getItem('theme') || 'dark';
    
    // Aplica o tema dark por padrão
    document.documentElement.setAttribute('data-bs-theme', savedTheme);
    
    // Atualiza o ícone do botão (mostra o sol pois o tema padrão é dark)
    updateThemeIcon(savedTheme);
    
    // Alterna o tema quando o botão é clicado
    themeToggle.addEventListener('click', () => {
        const currentTheme = document.documentElement.getAttribute('data-bs-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-bs-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateThemeIcon(newTheme);
        
        // Atualiza as cores dos medidores
        meterBk = newTheme === 'dark' ? "#2a2a2a" : "#80808040";
        updateUI(true);
    });
}
        
        function updateThemeIcon(theme) {
            const icon = I('themeToggle').querySelector('i');
            if (theme === 'dark') {
                icon.classList.replace('fa-moon', 'fa-sun');
            } else {
                icon.classList.replace('fa-sun', 'fa-moon');
            }
        }
        
        // Inicializa o tema
        setupTheme();
        
        //INITIALIZE SPEEDTEST
        var s = new Speedtest(); //create speedtest object


// Cores atualizadas
var dlColor = "#00F0FF";  // Ciano para Download
var ulColor = "#00FFA3";  // Verde para Upload
var meterBk = "rgba(0, 0, 0, 0.3)";  // Fundo escuro
var progColor = "#FFFFFF"; // Barra de progresso branca

function drawMeter(c, amount, bk, fg, progress, prog) {
    var ctx = c.getContext("2d");
    var dp = window.devicePixelRatio || 1;
    var cw = c.clientWidth * dp, ch = c.clientHeight * dp;
    var sizScale = ch * 0.0055;
    
    // Configuração do canvas
    if (c.width !== cw || c.height !== ch) {
        c.width = cw;
        c.height = ch;
    }
    ctx.clearRect(0, 0, cw, ch);

    // 1. Marcadores principais (0, 200, 400, 600, 800, 1000)
    ctx.beginPath();
    ctx.strokeStyle = "rgba(255, 255, 255, 0.5)";
    ctx.lineWidth = 2 * sizScale;
    ctx.font = `${10 * sizScale}px Arial`;
    ctx.fillStyle = "#FFFFFF";
    ctx.textAlign = "center";
    
    [0, 200, 400, 600, 800, 1000].forEach(speed => {
        const markAmount = speed / 1000; // Normaliza para 0-1
        const angle = -Math.PI * 1.1 + markAmount * Math.PI * 1.2;
        
        // Linha do marcador
        ctx.moveTo(
            c.width/2 + Math.cos(angle) * (c.height/1.8 - 30 * sizScale),
            c.height - 58 * sizScale + Math.sin(angle) * (c.height/1.8 - 30 * sizScale)
        );
        ctx.lineTo(
            c.width/2 + Math.cos(angle) * (c.height/1.8 - 15 * sizScale),
            c.height - 58 * sizScale + Math.sin(angle) * (c.height/1.8 - 15 * sizScale)
        );
        
        // Texto do marcador
        ctx.fillText(
            speed.toString(),
            c.width/2 + Math.cos(angle) * (c.height/1.8 - 45 * sizScale),
            c.height - 58 * sizScale + Math.sin(angle) * (c.height/1.8 - 45 * sizScale) + 5 * sizScale
        );
    });
    ctx.stroke();

    // 2. Fundo do medidor (trilha)
    ctx.beginPath();
    ctx.strokeStyle = bk;
    ctx.lineWidth = 12 * sizScale;
    ctx.arc(
        c.width/2,
        c.height - 58 * sizScale,
        c.height/1.8 - ctx.lineWidth,
        -Math.PI * 1.1,
        Math.PI * 0.1
    );
    ctx.stroke();

    // 3. Ponteiro central (agulha)
    const angle = -Math.PI * 1.1 + amount * Math.PI * 1.2;
    ctx.beginPath();
    ctx.strokeStyle = "#FF0000";
    ctx.lineWidth = 3 * sizScale;
    ctx.moveTo(c.width/2, c.height - 58 * sizScale);
    ctx.lineTo(
        c.width/2 + Math.cos(angle) * (c.height/1.8 - 25 * sizScale),
        c.height - 58 * sizScale + Math.sin(angle) * (c.height/1.8 - 25 * sizScale)
    );
    ctx.stroke();

    // 4. Medidor ativo
    ctx.beginPath();
    var gradient = ctx.createLinearGradient(
        0, c.height - 100 * sizScale,
        0, c.height
    );
    gradient.addColorStop(0, fg);
    gradient.addColorStop(1, mixColors(fg, "#FFFFFF", 0.5));
    
    ctx.strokeStyle = gradient;
    ctx.lineWidth = 10 * sizScale;
    ctx.lineCap = "round";
    ctx.shadowColor = fg;
    ctx.shadowBlur = 10 * sizScale;
    
    ctx.arc(
        c.width/2,
        c.height - 58 * sizScale,
        c.height/1.8 - ctx.lineWidth,
        -Math.PI * 1.1,
        angle
    );
    ctx.stroke();

    // 5. Valor atual (texto grande no centro)
    ctx.font = `${16 * sizScale}px Arial`;
    ctx.fillStyle = fg;
    ctx.textAlign = "center";
    ctx.fillText(
        Math.round(amount * 1000).toString(),
        c.width/2,
        c.height - 30 * sizScale
    );
    
    // 6. Barra de progresso
    if(typeof progress !== "undefined"){
        ctx.beginPath();
        ctx.fillStyle = prog;
        ctx.globalAlpha = 0.9;
        ctx.fillRect(
            c.width * 0.3,
            c.height - 16 * sizScale,
            c.width * 0.4 * progress,
            4 * sizScale
        );
        ctx.globalAlpha = 1.0;
    }
}

// Função auxiliar para misturar cores
function mixColors(color1, color2, weight) {
    // Implementação simplificada - na prática use uma lib de cores
    return weight > 0.5 ? color1 : color2;
}

// Atualize a conversão para escala 0-1000
function mbpsToAmount(s) {
    // Define a escala máxima do velocímetro (1000 Mbps)
    const maxSpeed = 1000;
    // Normaliza o valor para ficar entre 0 e 1 (onde 1000 Mbps = 1)
    return Math.min(s / maxSpeed, 1);
}
        function format(d) {
            d = Number(d);
            if (d < 10) return d.toFixed(2);
            if (d < 100) return d.toFixed(1);
            return d.toFixed(0);
        }

        //UI CODE
        var uiData = null;
        
        function startStop() {
            if (s.getState() == 3) {
                //speedtest is running, abort
                s.abort();
                uiData = null;
                I("startStopBtn").className = "btn btn-lg px-4 py-2";
                I("startStopBtn").innerHTML = '<i class="fas fa-play me-2"></i>Testar';
                initUI();
            } else {
                //test is not running, begin
                I("startStopBtn").className = "btn btn-lg px-4 py-2 running";
                I("startStopBtn").innerHTML = '<i class="fas fa-stop me-2"></i>Parar';
                
                s.onupdate = function(data) {
                    uiData = data;
                };
                
                s.onend = function(aborted) {
                    I("startStopBtn").className = "btn btn-lg px-4 py-2";
                    I("startStopBtn").innerHTML = '<i class="fas fa-play me-2"></i>Testar';
                    updateUI(true);
                };
                
                s.start();
            }
        }

        //this function reads the data sent back by the test and updates the UI
        function updateUI(forced) {
            if (!forced && s.getState() != 3) return;
            if (uiData == null) return;
            
            var status = uiData.testState;
            I("ip").textContent = uiData.clientIp;
            
            I("dlText").textContent = (status == 1 && uiData.dlStatus == 0) ? "..." : format(uiData.dlStatus);
            drawMeter(I("dlMeter"), mbpsToAmount(Number(uiData.dlStatus * (status == 1 ? oscillate() : 1))), meterBk, dlColor, Number(uiData.dlProgress), progColor);
            
            I("ulText").textContent = (status == 3 && uiData.ulStatus == 0) ? "..." : format(uiData.ulStatus);
            drawMeter(I("ulMeter"), mbpsToAmount(Number(uiData.ulStatus * (status == 3 ? oscillate() : 1))), meterBk, ulColor, Number(uiData.ulProgress), progColor);
            
            I("pingText").textContent = format(uiData.pingStatus);
            I("jitText").textContent = format(uiData.jitterStatus);
        }

        function oscillate() {
            return 1 + 0.02 * Math.sin(Date.now() / 100);
        }

        //update the UI every frame
        window.requestAnimationFrame = window.requestAnimationFrame || 
                                      window.webkitRequestAnimationFrame || 
                                      window.mozRequestAnimationFrame || 
                                      window.msRequestAnimationFrame || 
                                      (function(callback, element) { setTimeout(callback, 1000 / 60); });

        function frame() {
            requestAnimationFrame(frame);
            updateUI();
        }
        
        frame(); //start frame loop

        //function to (re)initialize UI
        function initUI() {
            drawMeter(I("dlMeter"), 0, meterBk, dlColor, 0);
            drawMeter(I("ulMeter"), 0, meterBk, ulColor, 0);
            I("dlText").textContent = "-";
            I("ulText").textContent = "-";
            I("pingText").textContent = "-";
            I("jitText").textContent = "-";
            I("ip").textContent = "";
        }
        
        // Initialize UI after short delay
        setTimeout(function() { initUI(); }, 100);
    </script>
</body>
</html>
