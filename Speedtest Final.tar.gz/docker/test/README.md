The files in this folder represent a simple end to end test.
At the moment it is interactive, so you need to run `docker compose up` in the folder and watch the output for errors.
Sometimes the mysql container needs more than 15 seconds, so the test_script fails.
Just try it again.